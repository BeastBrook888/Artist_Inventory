import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Arrays;

import javax.swing.DefaultCellEditor;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

public class FileReading_Methods {

	public static DefaultTableModel dtm = new DefaultTableModel();
	public static JTable memberslist;
	public static JScrollPane scrollPane_2;
	
    public String[] savefiles = new String[4];

	public String[] loadFileDestinations() {
		try {
			File f1 = new File("SaveFiles.txt"); // identifies text file
			if (f1.createNewFile())
			{
			    System.out.println("'SaveFiles.txt' is created!");
			} else {
			    System.out.println("'SaveFiles.txt' already exists.");
			}
			FileReader in = new FileReader(f1); // prepares to read file
			BufferedReader r = new BufferedReader(in); // actually reads and extracts from the file

			while (true) {

				String line1 = r.readLine();
				String line2 = r.readLine();
				String line3 = r.readLine();
				String line4 = r.readLine();
				
				if (line1 == null || line2 == null || line3 == null || line4 == null) {
					break;
				}
				
				savefiles[0] = line1;
				savefiles[1] = line2;
				savefiles[2] = line3;
				savefiles[3] = line4;

		}

			r.close();
			System.out.println("Success!");
		}

		catch (Exception e2) {
			System.out.println("SaveFiles.txt Reading doesn't work: " + e2);
		}
		
		return savefiles;
	}
	
	public void setUpComboBoxCells(JTable table, TableColumn columnName, String filename) {
		// READ FROM FILE TO UPLOAD EXISTING DATA INTO THE TABLE
		
		JComboBox comboBox = new JComboBox();
		comboBox.addItem("???");
		
		try {
					File f1 = new File(filename + ".txt"); // identifies text file
					if (f1.createNewFile()) {
						System.out.println(filename + ".txt" + " is created!");
					} else {
						System.out.println(filename + ".txt" + " already exists.");
					}
					FileReader in = new FileReader(f1); // prepares to read file
					BufferedReader r = new BufferedReader(in); // actually reads and extracts from the file

					while (true) {
						String choice = r.readLine();

						if(choice == null) break;
						
						comboBox.addItem(choice);

					}

					r.close();
				}

				catch (Exception e2) {
					System.out.println(filename + "reading doesn't work: " + e2);
				}
		
		columnName.setCellEditor(new DefaultCellEditor(comboBox));
		
		columnName.setCellRenderer(new TableCellRenderer() {
		    JComboBox box = new JComboBox();

		    //https://stackoverflow.com/questions/30744524/how-to-make-the-jcombobox-dropdown-always-visible-in-a-jtable
		    @Override
		    public JComboBox getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
		            int row, int column) {
		        box.removeAllItems();
		        box.addItem(value.toString());
		        return box;
		    }
		});

	}
	
	public void readIntoTable(String filename, Object[] colNames, DefaultTableModel dtm, JTable tab1e) {
		Object[] columns = colNames;
		int arrLength = columns.length;

		// READ FROM FILE TO UPLOAD EXISTING DATA INTO THE TABLE
		try {
			File f1 = new File(filename + ".txt"); // identifies text file
			if (f1.createNewFile()) {
				System.out.println(filename + ".txt" + " is created!");
			} else {
				System.out.println(filename + ".txt" + " already exists.");
			}
			FileReader in = new FileReader(f1); // prepares to read file
			BufferedReader r = new BufferedReader(in); // actually reads and extracts from the file

			outerloop: //label to be able to break the whole loop while inside the for-loop
				//https://stackoverflow.com/questions/886955/how-do-i-break-out-of-nested-loops-in-java
			while (true) {
				String tempArr[] = new String[arrLength];
				
				for(int i = 0; i < arrLength; i++) {
					tempArr[i] = r.readLine();
				}
				
				for(int j = 0; j < arrLength; j++) {
					if(tempArr[j] == null) {
						break outerloop;
					}
				}

				Object[] row = new Object[arrLength];
				
				if (memberslist == null) {
				for(int i = 0; i < arrLength; i++) {
					row[i] = tempArr[i];
				}

					dtm.addRow(row);
				}

			}

			r.close();
		}

		catch (Exception e2) {
			System.out.println(filename + "reading doesn't work: " + e2);
		}
	}
	
	public void data_validation(JTable table, Object[] columnNums) {
		if(table.getCellEditor() != null) {
			
			if(Arrays.asList(columnNums).contains(table.getEditingColumn())) {
				
			}
			
		}
	}

}
